/* Lab 10: switch-controlled countdown, RV32I, byte-addressed MMIO
 * 0x200 LED data; 0x300 switches; 0x304 button reset.
 * COUNT_DELAY is set by build script for realistic/simulated ROM.
 */
.section .text
.globl _start
_start:
    addi sp, zero, 256
    addi t0, zero, 512
    addi t1, zero, 768
    addi t2, zero, 772
    sw zero, 0(t0)
wait_input:
    lw t3, 0(t2)
    bne t3, zero, reset_idle
    lw a0, 0(t1)
    beq a0, zero, wait_input
    andi a0, a0, 15
    beq a0, zero, wait_input
    jal ra, countdown
    beq zero, zero, wait_input
reset_idle:
    sw zero, 0(t0)
    beq zero, zero, wait_input
countdown:
    addi sp, sp, -8
    sw ra, 4(sp)
    sw s0, 0(sp)
    add s0, a0, zero
count_loop:
    lw t3, 0(t2)
    bne t3, zero, abort_count
    sw s0, 0(t0)
    beq s0, zero, done_count
    addi s0, s0, -1
    addi t4, zero, COUNT_DELAY
outer_loop:
    addi t5, zero, COUNT_DELAY
inner_loop:
    addi t5, t5, -1
    bne t5, zero, inner_loop
    lw t3, 0(t2)
    bne t3, zero, abort_count
    addi t4, t4, -1
    bne t4, zero, outer_loop
    beq zero, zero, count_loop
abort_count:
    sw zero, 0(t0)
done_count:
    lw s0, 0(sp)
    lw ra, 4(sp)
    addi sp, sp, 8
    jalr zero, 0(ra)
