from pathlib import Path
import subprocess, shutil
p=Path(__file__).resolve().parent
for suffix,delay in [('hardware',1000),('simulation',2)]:
    asm=(p/'fsm_countdown.S').read_text().replace('COUNT_DELAY',str(delay))
    (p/f'fsm_{suffix}.S').write_text(asm)
    obj=p/f'fsm_{suffix}.elf'
    cmd=['clang','--target=riscv32-unknown-elf','-march=rv32i','-mabi=ilp32','-nostdlib','-fno-pic','-Wl,-Ttext=0x0','-Wl,--no-relax','-Wl,--entry=_start',str(p/f'fsm_{suffix}.S'),'-o',str(obj)]
    subprocess.run(cmd,check=True)
    b=p/f'fsm_{suffix}.bin'
    subprocess.run(['llvm-objcopy','-O','binary',str(obj),str(b)],check=True)
    data=b.read_bytes()
    if len(data)>256: raise ValueError(f'ROM exceeds 256 bytes: {len(data)}')
    (p/f'fsm_{suffix}.mem').write_text('\n'.join(f'{x:02x}' for x in data)+'\n')
    (p/f'fsm_{suffix}_words.txt').write_text('\n'.join(f'{i:04x}: {int.from_bytes(data[i:i+4],"little"):08x}' for i in range(0,len(data),4))+'\n')
    print(suffix, len(data), 'bytes',len(data)//4,'instructions')
