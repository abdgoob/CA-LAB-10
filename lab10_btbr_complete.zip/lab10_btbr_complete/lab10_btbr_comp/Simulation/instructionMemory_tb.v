`timescale 1ns/1ps
module instructionMemory_tb;
    reg [31:0] pc = 0;
    wire [31:0] inst;
    integer errors=0;
    instructionMemory #(.MEMFILE("fsm_simulation.mem")) dut(.instAddress(pc),.instruction(inst));
    initial begin
        #1;
        if(inst !== 32'h10000113) begin $display("FAIL first instruction: %h",inst); errors=errors+1; end
        pc=4; #1;
        if(inst !== 32'h20000293) begin $display("FAIL second instruction: %h",inst); errors=errors+1; end
        pc=0; #1;
        if(inst !== 32'h10000113) begin $display("FAIL PC returning to 0"); errors=errors+1; end
        pc=252; #1; // valid aligned final word
        pc=256; #1;
        if(inst !== 32'h00000013) begin $display("FAIL out of bounds"); errors=errors+1; end
        if(errors==0) $display("PASS instructionMemory fetch / endian / PC indexing");
        else $display("FAIL %0d checks",errors);
        $finish;
    end
endmodule
