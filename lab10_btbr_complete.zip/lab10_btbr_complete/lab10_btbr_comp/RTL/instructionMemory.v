`timescale 1ns/1ps
// ROM: byte-addressed 256-byte instruction image, 32-bit little-endian fetch.
// Add the .mem file as a Vivado Memory Initialization File (design source).
module instructionMemory #(
    parameter OPERAND_LENGTH = 31,
    parameter MEMFILE = "fsm_hardware.mem"
)(
    input [OPERAND_LENGTH:0] instAddress,
    output reg [31:0] instruction
);
    reg [7:0] memory [0:255];
    integer i;
    initial begin
        for (i=0; i<256; i=i+1) memory[i]=8'h00;
        $readmemh(MEMFILE, memory);
    end
    always @(*) begin
        if (instAddress <= 32'd252 && instAddress[1:0] == 2'b00)
            instruction = {memory[instAddress+3],memory[instAddress+2],
                           memory[instAddress+1],memory[instAddress]};
        else instruction = 32'h00000013; // NOP on invalid/out-of-bounds PC
    end
endmodule
